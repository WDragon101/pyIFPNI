This is a python package accessing to IFPNI flexible.

# Install pyIFPNI package

> pip install pyIFPNI

# 